import csv
import math
import os
import random
from pathlib import Path
from typing import Dict, List, Tuple

from cpp_evaluator import Chromosome, CPPEvaluator, EvaluationResult


AGV_CAPACITY = 2
BASE_DIR = Path(__file__).resolve().parent


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


class GAAStarCPOptimizer:
    """Upper-level GA optimizer for TAS, with lower-level A*-CP feedback.

    This version keeps explicit task -> AGV assignment in the chromosome:

        Chromosome.task_order: global task priority/order
        Chromosome.agv_assign: task_id -> agv_id

    Important modeling choices in this version:
    1. Fixed AGV set: self.agv_ids comes from planner.active_agvs.
    2. The chromosome explicitly stores AGV IDs. CPP evaluation must execute
       the assigned AGV task sequences, not dynamically choose AGVs.
    3. release_time is ignored by the GA task allocation logic. Initial
       sequences are based on window_start / window_end only.
    4. The GA is strengthened with load-balanced initialization, AGV assignment
       mutation, AGV-load swap mutation, and load-balance repair so that idle
       AGVs are less likely while other AGVs are overloaded.
    """

    def __init__(
        self,
        planner,
        population_size=6,
        generations=5,
        crossover_rate=0.85,
        mutation_rate=0.30,
        elite_size=3,
        tournament_k=3,
        seed=42,
    ):
        self.planner = planner
        self.population_size = int(os.environ.get("GA_POPULATION", population_size))
        self.generations = int(os.environ.get("GA_GENERATIONS", generations))
        self.crossover_rate = float(os.environ.get("GA_CROSSOVER_RATE", crossover_rate))
        self.mutation_rate = float(os.environ.get("GA_MUTATION_RATE", mutation_rate))
        self.elite_size = int(os.environ.get("GA_ELITE_SIZE", elite_size))
        self.tournament_k = int(os.environ.get("GA_TOURNAMENT_K", tournament_k))
        self.elite_size = max(1, min(self.elite_size, self.population_size))

        self.rng = random.Random(seed)
        self.evaluator = CPPEvaluator(planner)

        self.task_ids = [t["task_id"] for t in planner.tasks]
        self.task_by_id = {t["task_id"]: t for t in planner.tasks}
        self.agv_ids = list(planner.active_agvs)

        # Generate sub-tasks based on demand
        self.sub_tasks = []
        self.required_subtask_count = {}
        for tid in self.task_ids:
            task = self.task_by_id[tid]
            demand = int(task["demand"])
            if demand not in (2, 4, 6, 8):
                raise ValueError(f"Task {tid} has invalid demand={demand}; expected one of 2, 4, 6, 8.")
            num_sub = math.ceil(demand / AGV_CAPACITY)
            self.required_subtask_count[tid] = num_sub
            self.sub_tasks.extend([tid] * num_sub)

        if not self.agv_ids:
            raise ValueError("planner.active_agvs is empty. Fixed active AGVs must be configured first.")
        if len(self.agv_ids) < max(self.required_subtask_count.values(), default=1):
            raise ValueError("Not enough active AGVs for the largest collaborative task demand.")

        self.cache: Dict[Tuple, EvaluationResult] = {}
        self.history: List[dict] = []

        collaborative_count = sum(1 for count in self.required_subtask_count.values() if count > 1)
        print(
            f"GA collaborative encoding | original_tasks={len(self.task_ids)} | "
            f"task_genes={len(self.sub_tasks)} | collaborative_tasks={collaborative_count} | "
            f"agv_capacity={AGV_CAPACITY}",
            flush=True,
        )

    # ------------------------------------------------------------------
    # Chromosome creation and repair
    # ------------------------------------------------------------------

    def _window_key(self, tid: str):
        """Task sorting key. Do not use release_time for task assignment."""
        task = self.task_by_id[tid]
        return (
            int(task["window_start"]),
            int(task["window_end"]),
            task["task_id"],
        )

    def _due_key(self, tid: str):
        """Earliest-due-date key. Do not use release_time."""
        task = self.task_by_id[tid]
        return (
            int(task["window_end"]),
            int(task["window_start"]),
            task["task_id"],
        )

    def _cache_key(self, chrom: Chromosome):
        # Assignment is part of the chromosome and must be part of the cache key.
        return (
            tuple(chrom.task_order),
            tuple(sorted(chrom.agv_assign.items())),  # Sort for consistent hashing
        )

    def _copy_chrom(self, chrom: Chromosome) -> Chromosome:
        return Chromosome(list(chrom.task_order), dict(chrom.agv_assign))

    def _interleaved_order(self, ordered_task_ids: List[str]) -> List[str]:
        """Spread repeated task IDs across the sequence instead of grouping copies."""
        max_count = max(self.required_subtask_count.values(), default=1)
        order = []
        for occ in range(max_count):
            for tid in ordered_task_ids:
                if occ < self.required_subtask_count[tid]:
                    order.append(tid)
        return order

    def _normalize_chromosome(self, chrom: Chromosome) -> Chromosome:
        """Ensure the chromosome has the correct sub-tasks and legal AGV assignments."""
        # Ensure task_order has the correct sub-task multiset.
        required_counts = {}
        for tid in self.sub_tasks:
            required_counts[tid] = required_counts.get(tid, 0) + 1

        clean_order = []
        current_counts = {}
        for tid in chrom.task_order:
            if tid not in required_counts:
                continue
            count = current_counts.get(tid, 0)
            if count < required_counts[tid]:
                clean_order.append(tid)
                current_counts[tid] = count + 1

        missing = []
        for tid, required in required_counts.items():
            missing.extend([tid] * (required - current_counts.get(tid, 0)))

        # Append missing sub-tasks in window order to keep schedule sensible.
        missing.sort(key=self._window_key)
        clean_order.extend(missing)
        chrom.task_order = clean_order

        # Ensure agv_assign covers all sub-tasks.
        clean_assign: Dict[Tuple[str, int], str] = {}
        occurrence_count = {}
        for tid in chrom.task_order:
            occ = occurrence_count.get(tid, 0)
            key = (tid, occ)
            aid = chrom.agv_assign.get(key, self.rng.choice(self.agv_ids))
            if aid not in self.agv_ids:
                aid = self.rng.choice(self.agv_ids)
            clean_assign[key] = aid
            occurrence_count[tid] = occ + 1

        chrom.agv_assign = clean_assign
        self._repair_same_task_collaboration(chrom)
        return chrom

    def _repair_same_task_collaboration(self, chrom: Chromosome):
        """Prefer distinct AGVs for duplicated genes of the same original task."""
        loads = {aid: 0 for aid in self.agv_ids}
        for aid in chrom.agv_assign.values():
            if aid in loads:
                loads[aid] += 1

        keys_by_task = {}
        for key in chrom.agv_assign:
            tid, _ = key
            keys_by_task.setdefault(tid, []).append(key)

        for tid, keys in keys_by_task.items():
            if len(keys) <= 1:
                continue

            keys.sort(key=lambda item: item[1])
            used = set()
            for key in keys:
                aid = chrom.agv_assign[key]
                if aid not in used:
                    used.add(aid)
                    continue

                unused = [candidate for candidate in self.agv_ids if candidate not in used]
                if not unused:
                    continue

                new_aid = min(unused, key=lambda candidate: (loads[candidate], int(candidate)))
                loads[aid] -= 1
                loads[new_aid] += 1
                chrom.agv_assign[key] = new_aid
                used.add(new_aid)

    def _round_robin_assign(self, order: List[str]) -> Dict[Tuple[str, int], str]:
        """Balanced deterministic assignment by current order."""
        assign = {}
        occurrence_count = {}
        for i, tid in enumerate(order):
            occ = occurrence_count.get(tid, 0)
            offset = sum(ord(ch) for ch in tid) % len(self.agv_ids)
            assign[(tid, occ)] = self.agv_ids[(i + offset) % len(self.agv_ids)]
            occurrence_count[tid] = occ + 1
        return assign

    def _balanced_random_assign(self, order: List[str]) -> Dict[Tuple[str, int], str]:
        """Randomized assignment, but keep AGV task counts balanced."""
        assign = {}
        loads = {aid: 0 for aid in self.agv_ids}
        occurrence_count = {}

        for tid in order:
            occ = occurrence_count.get(tid, 0)
            key = (tid, occ)
            min_load = min(loads.values())
            # Choose among the least-loaded AGVs. This avoids initial idle AGVs.
            candidates = [aid for aid in self.agv_ids if loads[aid] == min_load]
            already_used = {
                assign[(tid, prev_occ)]
                for prev_occ in range(occ)
                if (tid, prev_occ) in assign
            }
            distinct_candidates = [aid for aid in candidates if aid not in already_used]
            if not distinct_candidates:
                distinct_candidates = [aid for aid in self.agv_ids if aid not in already_used]
            if distinct_candidates:
                candidates = distinct_candidates
            aid = self.rng.choice(candidates)
            assign[key] = aid
            loads[aid] += 1
            occurrence_count[tid] = occ + 1

        return assign

    def _balanced_window_assign(self, order: List[str]) -> Dict[Tuple[str, int], str]:
        """Balanced assignment for tasks sorted by time-window start.

        Since all AGVs share the same virtual home in this project, distance from
        home usually does not distinguish AGVs. Therefore the main useful prior
        is load balance. This function is deterministic and stable.
        """
        assign = {}
        loads = {aid: 0 for aid in self.agv_ids}
        occurrence_count = {}

        for tid in order:
            occ = occurrence_count.get(tid, 0)
            key = (tid, occ)
            already_used = {
                assign[(tid, prev_occ)]
                for prev_occ in range(occ)
                if (tid, prev_occ) in assign
            }
            candidates = [aid for aid in self.agv_ids if aid not in already_used] or self.agv_ids
            offset = sum(ord(ch) for ch in tid) % len(self.agv_ids)
            aid = min(candidates, key=lambda a: (loads[a], (int(a) - offset) % len(self.agv_ids)))
            assign[key] = aid
            loads[aid] += 1
            occurrence_count[tid] = occ + 1

        return assign

    def _random_chromosome(self) -> Chromosome:
        order = self.sub_tasks[:]
        self.rng.shuffle(order)

        # Prefer balanced random assignment over fully random assignment.
        if self.rng.random() < 0.80:
            assign = self._balanced_random_assign(order)
        else:
            assign = {}
            occurrence_count = {}
            for tid in order:
                occ = occurrence_count.get(tid, 0)
                assign[(tid, occ)] = self.rng.choice(self.agv_ids)
                occurrence_count[tid] = occ + 1

        chrom = Chromosome(order, assign)
        self._repair_assignment_by_load(chrom, max_moves=3)
        return self._normalize_chromosome(chrom)

    def _initial_population(self) -> List[Chromosome]:
        pop: List[Chromosome] = []

        task_ids_window = sorted(self.task_ids, key=self._window_key)
        task_ids_edd = sorted(self.task_ids, key=self._due_key)
        order_window = [tid for tid in task_ids_window for _ in range(self.required_subtask_count[tid])]
        order_window_interleaved = self._interleaved_order(task_ids_window)
        order_edd_interleaved = self._interleaved_order(task_ids_edd)

        # Seed 1: time-window order + round-robin assignment.
        pop.append(Chromosome(order_window[:], self._round_robin_assign(order_window)))

        # Seed 2: interleaved time-window order + deterministic balanced assignment.
        pop.append(Chromosome(order_window_interleaved[:], self._balanced_window_assign(order_window_interleaved)))

        # Seed 3: interleaved earliest due date + round-robin assignment.
        pop.append(Chromosome(order_edd_interleaved[:], self._round_robin_assign(order_edd_interleaved)))

        # Seed 4: interleaved earliest due date + balanced random assignment.
        pop.append(Chromosome(order_edd_interleaved[:], self._balanced_random_assign(order_edd_interleaved)))

        # Seed 5: time-window order + balanced random assignment.
        # Keep it after the deterministic seeds so small populations still get diversity.
        pop.append(Chromosome(order_window[:], self._balanced_random_assign(order_window)))

        # Random diversified individuals.
        while len(pop) < self.population_size:
            pop.append(self._random_chromosome())

        pop = [self._normalize_chromosome(chrom) for chrom in pop[: self.population_size]]
        return pop

    def _loads(self, chrom: Chromosome) -> Dict[str, int]:
        loads = {aid: 0 for aid in self.agv_ids}
        for aid in chrom.agv_assign.values():
            if aid in loads:
                loads[aid] += 1
        return loads

    def _repair_assignment_by_load(self, chrom: Chromosome, max_moves: int = 2):
        """Repair obviously unbalanced assignment while keeping explicit AGV IDs.

        This is not dynamic AGV selection at runtime. It rewrites genes in the
        chromosome before evaluation, so final task assignment still contains
        explicit AGV IDs.
        """
        if len(self.agv_ids) <= 1:
            return

        chrom = self._normalize_chromosome(chrom)
        loads = self._loads(chrom)

        moves = 0
        while moves < max_moves:
            heavy = max(self.agv_ids, key=lambda aid: (loads[aid], -int(aid)))
            light = min(self.agv_ids, key=lambda aid: (loads[aid], int(aid)))

            if loads[heavy] - loads[light] < 2:
                break

            heavy_tasks = [key for key, aid in chrom.agv_assign.items() if aid == heavy]
            if not heavy_tasks:
                break

            # Move one task from the most loaded AGV to the least loaded AGV.
            # Prefer a later task to reduce disruption of early time-window tasks.
            cutoff = max(1, len(heavy_tasks) // 2)
            candidates = heavy_tasks[cutoff:] or heavy_tasks
            key = self.rng.choice(candidates)

            chrom.agv_assign[key] = light
            loads[heavy] -= 1
            loads[light] += 1
            moves += 1

        self._repair_same_task_collaboration(chrom)

    # ------------------------------------------------------------------
    # GA operators
    # ------------------------------------------------------------------

    def _tournament(self, scored):
        sample = self.rng.sample(scored, min(self.tournament_k, len(scored)))
        return self._copy_chrom(min(sample, key=lambda x: x[0])[1])

    def _order_crossover(self, p1: List[str], p2: List[str]) -> Tuple[List[str], List[str]]:
        n = len(p1)
        if n < 2:
            return p1[:], p2[:]

        a, b = sorted(self.rng.sample(range(n), 2))

        def ox(x, y):
            child = [None] * n
            child[a:b + 1] = x[a:b + 1]

            # Count how many of each value are already in the copied segment.
            required_counts = {}
            for tid in x:
                required_counts[tid] = required_counts.get(tid, 0) + 1

            current_counts = {}
            for v in child[a:b + 1]:
                if v is not None:
                    current_counts[v] = current_counts.get(v, 0) + 1

            # Fill the remaining positions from y while preserving counts.
            fill = []
            for v in y:
                needed = required_counts.get(v, 0) - current_counts.get(v, 0)
                if needed > 0:
                    fill.append(v)
                    current_counts[v] = current_counts.get(v, 0) + 1

            ptr = 0
            for idx in list(range(b + 1, n)) + list(range(0, b + 1)):
                if child[idx] is None:
                    child[idx] = fill[ptr]
                    ptr += 1
            return child

        return ox(p1, p2), ox(p2, p1)

    def _crossover(self, a: Chromosome, b: Chromosome) -> Tuple[Chromosome, Chromosome]:
        if self.rng.random() > self.crossover_rate:
            return self._copy_chrom(a), self._copy_chrom(b)

        c1_order, c2_order = self._order_crossover(a.task_order, b.task_order)

        # Uniform crossover for explicit task -> AGV assignment.
        c1_assign = {}
        c2_assign = {}
        all_keys = set(a.agv_assign.keys()) | set(b.agv_assign.keys())
        for key in all_keys:
            a_aid = a.agv_assign.get(key, self.rng.choice(self.agv_ids))
            b_aid = b.agv_assign.get(key, self.rng.choice(self.agv_ids))

            if self.rng.random() < 0.5:
                c1_assign[key] = a_aid
                c2_assign[key] = b_aid
            else:
                c1_assign[key] = b_aid
                c2_assign[key] = a_aid

        c1 = Chromosome(c1_order, c1_assign)
        c2 = Chromosome(c2_order, c2_assign)

        self._normalize_chromosome(c1)
        self._normalize_chromosome(c2)

        # Light repair after crossover to avoid children with very idle AGVs.
        self._repair_assignment_by_load(c1, max_moves=2)
        self._repair_assignment_by_load(c2, max_moves=2)

        return c1, c2

    def _mutate(self, chrom: Chromosome):
        chrom = self._normalize_chromosome(chrom)

        if self.rng.random() > self.mutation_rate:
            return

        n = len(chrom.task_order)
        if n == 0:
            return

        # Include both sequence mutations and explicit AGV assignment mutations.
        op = self.rng.choice([
            "swap_order",
            "invert_order",
            "relocate_order",
            "scatter_same_task",
            "change_agv",
            "swap_agv_load",
            "shuffle_task_agvs",
            "rebalance_agv",
        ])

        if op == "swap_order" and n >= 2:
            i, j = self.rng.sample(range(n), 2)
            chrom.task_order[i], chrom.task_order[j] = chrom.task_order[j], chrom.task_order[i]

        elif op == "invert_order" and n >= 2:
            i, j = sorted(self.rng.sample(range(n), 2))
            chrom.task_order[i:j + 1] = list(reversed(chrom.task_order[i:j + 1]))

        elif op == "relocate_order" and n >= 2:
            i, j = self.rng.sample(range(n), 2)
            tid = chrom.task_order.pop(i)
            chrom.task_order.insert(j, tid)

        elif op == "scatter_same_task" and n >= 2:
            repeated = [tid for tid, count in self.required_subtask_count.items() if count > 1]
            if repeated:
                tid = self.rng.choice(repeated)
                copies = [x for x in chrom.task_order if x == tid]
                rest = [x for x in chrom.task_order if x != tid]
                chrom.task_order = rest
                for copy in copies:
                    pos = self.rng.randrange(len(chrom.task_order) + 1)
                    chrom.task_order.insert(pos, copy)

        elif op == "change_agv":
            if chrom.agv_assign:
                key = self.rng.choice(list(chrom.agv_assign.keys()))
                old = chrom.agv_assign[key]
                choices = [aid for aid in self.agv_ids if aid != old]
                if choices:
                    chrom.agv_assign[key] = self.rng.choice(choices)

        elif op == "swap_agv_load" and len(chrom.agv_assign) >= 2:
            k1, k2 = self.rng.sample(list(chrom.agv_assign.keys()), 2)
            chrom.agv_assign[k1], chrom.agv_assign[k2] = chrom.agv_assign[k2], chrom.agv_assign[k1]

        elif op == "shuffle_task_agvs":
            repeated = [tid for tid, count in self.required_subtask_count.items() if count > 1]
            if repeated:
                tid = self.rng.choice(repeated)
                keys = [(tid, occ) for occ in range(self.required_subtask_count[tid])]
                choices = self.rng.sample(self.agv_ids, min(len(keys), len(self.agv_ids)))
                for key, aid in zip(keys, choices):
                    chrom.agv_assign[key] = aid

        elif op == "rebalance_agv":
            self._repair_assignment_by_load(chrom, max_moves=2)

        # Extra small probability: mutate another AGV assignment.
        # This helps escape local optima where one AGV is overloaded.
        if self.rng.random() < 0.35 and chrom.task_order:
            tid = self.rng.choice(chrom.task_order)
            # Find the first occurrence
            occurrence_count = {}
            key = None
            for t in chrom.task_order:
                occ = occurrence_count.get(t, 0)
                if t == tid and key is None:
                    key = (t, occ)
                    break
                occurrence_count[t] = occ + 1
            if key:
                old = chrom.agv_assign.get(key)
                choices = [aid for aid in self.agv_ids if aid != old]
                if choices:
                    chrom.agv_assign[key] = self.rng.choice(choices)

        # Always normalize and lightly repair after mutation.
        self._normalize_chromosome(chrom)
        if self.rng.random() < 0.75:
            self._repair_assignment_by_load(chrom, max_moves=2)

    # ------------------------------------------------------------------
    # Evaluation and output
    # ------------------------------------------------------------------

    def _evaluate(self, chrom: Chromosome) -> EvaluationResult:
        self._normalize_chromosome(chrom)
        key = self._cache_key(chrom)
        ev = self.cache.get(key)
        if ev is None:
            ev = self.evaluator.evaluate(chrom, detailed=False)
            self.cache[key] = ev
        return ev

    def _write_history(self):
        with open(BASE_DIR / "ga_history.csv", "w", newline="", encoding="utf-8-sig") as f:
            fields = [
                "generation",
                "improved",
                "best_score",
                "generation_best_score",
                "generation_avg_score",
                "unique_score_count",
                "generation_tardiness",
                "generation_max_tardiness",
                "generation_late_task_count",
                "generation_makespan",
                "generation_total_distance",
                "generation_total_wait",
                "generation_workload_imbalance",
                "generation_total_sync_gap",
                "generation_duplicate_agv_penalty",
                "generation_collaborative_task_count",
                "best_tardiness",
                "best_max_tardiness",
                "best_late_task_count",
                "best_makespan",
                "best_total_distance",
                "best_total_wait",
                "best_workload_imbalance",
                "best_total_sync_gap",
                "best_duplicate_agv_penalty",
                "best_collaborative_task_count",
            ]
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(self.history)

    def _write_best_chromosome(self, chrom: Chromosome, ev: EvaluationResult):
        # This file is the chromosome itself: every task gene has an explicit AGV ID.
        with open(BASE_DIR / "best_chromosome.csv", "w", newline="", encoding="utf-8-sig") as f:
            fields = ["gene_index", "task_id", "occurrence", "assigned_agv"]
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            occurrence_count = {}
            for gene_index, tid in enumerate(chrom.task_order):
                occ = occurrence_count.get(tid, 0)
                key = (tid, occ)
                writer.writerow({
                    "gene_index": gene_index,
                    "task_id": tid,
                    "occurrence": occ,
                    "assigned_agv": chrom.agv_assign.get(key, ""),
                })
                occurrence_count[tid] = occ + 1

        # This file is the decoded AGV sequence that CPP actually evaluated.
        with open(BASE_DIR / "best_agv_sequences.csv", "w", newline="", encoding="utf-8-sig") as f:
            fields = ["agv_id", "sequence_index", "task_id"]
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for aid, seq in ev.agv_task_sequences.items():
                for i, tid in enumerate(seq):
                    writer.writerow({
                        "agv_id": aid,
                        "sequence_index": i,
                        "task_id": tid,
                    })

    # ------------------------------------------------------------------
    # Main solve
    # ------------------------------------------------------------------

    def solve(self) -> Tuple[Chromosome, EvaluationResult]:
        population = self._initial_population()

        global_best_chrom = None
        global_best_eval = None
        global_best_score = float("inf")

        for gen in range(self.generations):
            scored = []
            for chrom in population:
                ev = self._evaluate(chrom)
                scored.append((ev.score, chrom, ev))

            scored.sort(key=lambda x: x[0])
            gen_best_score, gen_best_chrom, gen_best_eval = scored[0]
            gen_avg_score = sum(item[0] for item in scored) / len(scored)
            unique_scores = len({round(item[0], 4) for item in scored})
            improved = gen_best_score < global_best_score

            if improved:
                global_best_score = gen_best_score
                global_best_chrom = self._copy_chrom(gen_best_chrom)
                global_best_eval = gen_best_eval

            self.history.append({
                "generation": gen,
                "improved": int(improved),
                "best_score": round(global_best_score, 4),
                "generation_best_score": round(gen_best_score, 4),
                "generation_avg_score": round(gen_avg_score, 4),
                "unique_score_count": unique_scores,
                "generation_tardiness": gen_best_eval.total_tardiness,
                "generation_max_tardiness": gen_best_eval.max_tardiness,
                "generation_late_task_count": gen_best_eval.late_task_count,
                "generation_makespan": gen_best_eval.makespan,
                "generation_total_distance": gen_best_eval.total_distance,
                "generation_total_wait": gen_best_eval.total_wait,
                "generation_workload_imbalance": gen_best_eval.workload_imbalance,
                "generation_total_sync_gap": gen_best_eval.total_sync_gap,
                "generation_duplicate_agv_penalty": gen_best_eval.duplicate_agv_penalty,
                "generation_collaborative_task_count": gen_best_eval.collaborative_task_count,
                "best_tardiness": global_best_eval.total_tardiness,
                "best_max_tardiness": global_best_eval.max_tardiness,
                "best_late_task_count": global_best_eval.late_task_count,
                "best_makespan": global_best_eval.makespan,
                "best_total_distance": global_best_eval.total_distance,
                "best_total_wait": global_best_eval.total_wait,
                "best_workload_imbalance": global_best_eval.workload_imbalance,
                "best_total_sync_gap": global_best_eval.total_sync_gap,
                "best_duplicate_agv_penalty": global_best_eval.duplicate_agv_penalty,
                "best_collaborative_task_count": global_best_eval.collaborative_task_count,
            })

            print(
                f"GA gen {gen:03d} | "
                f"best={global_best_score:.2f}{'*' if improved else ''} | "
                f"gen_best={gen_best_score:.2f} | "
                f"gen_avg={gen_avg_score:.2f} | "
                f"unique={unique_scores} | "
                f"gen_late={gen_best_eval.late_task_count} | "
                f"gen_tard={gen_best_eval.total_tardiness} | "
                f"gen_makespan={gen_best_eval.makespan} | "
                f"gen_dist={gen_best_eval.total_distance} | "
                f"gen_wait={gen_best_eval.total_wait} | "
                f"gen_imbalance={gen_best_eval.workload_imbalance} | "
                f"gen_sync={gen_best_eval.total_sync_gap} | "
                f"gen_dup={gen_best_eval.duplicate_agv_penalty} | "
                f"coop={gen_best_eval.collaborative_task_count}"
                ,
                flush=True,
            )

            # Elitism.
            next_pop = [self._copy_chrom(item[1]) for item in scored[: self.elite_size]]

            while len(next_pop) < self.population_size:
                p1 = self._tournament(scored)
                p2 = self._tournament(scored)
                c1, c2 = self._crossover(p1, p2)
                self._mutate(c1)
                self._mutate(c2)

                next_pop.append(c1)
                if len(next_pop) < self.population_size:
                    next_pop.append(c2)

            population = next_pop

        # Re-evaluate best in detailed mode to obtain final tracks and outputs.
        final_eval = self.evaluator.evaluate(global_best_chrom, detailed=True)
        self._write_history()
        self._write_best_chromosome(global_best_chrom, final_eval)

        return global_best_chrom, final_eval
