﻿import csv
import json
import random
from dataclasses import dataclass
from pathlib import Path


GRID_W = 106
GRID_H = 90
RANDOM_SEED = 42
TAKT_SECONDS_PER_HOUR = 3600
AGV_SECONDS_PER_STEP = 5
TAKT_TO_AGV_TIME = TAKT_SECONDS_PER_HOUR // AGV_SECONDS_PER_STEP

STATION_W = 3
STATION_H = 3
LAYOUT_CELL_SPACING = 6
LAYOUT_X0 = 4
LAYOUT_Y0 = -1
BASE_DIR = Path(__file__).resolve().parent

MAX_CANDIDATE_AGVS = 10

SHARED_HOME_X = 101
SHARED_HOME_Y = 32
SUPPLY_POS = (98, 32)

PICKUP_POINTS = [
    ("PICK-1", "P1", 97, 31),
    ("PICK-2", "P2", 97, 33),
]

TASK_ROUNDS_PER_STATION = 1
TASK_GAP_MIN = 28
TASK_GAP_MAX = 68
WINDOW_LEN_MIN = 45
WINDOW_LEN_MAX = 105
RELEASE_LEAD_MIN = 20
RELEASE_LEAD_MAX = 60

MATERIALS = ["M1", "M2", "M3", "M4", "M5"]
DEMAND_VALUES = [2, 4, 6, 8]


@dataclass
class AGVHome:
    name: str
    x: int
    y: int
    pitch: int = 180


@dataclass
class DropPoint:
    name: str
    label: str
    x: int
    y: int


def find_layout_file():
    matches = sorted(BASE_DIR.glob("*/result.json"))
    if not matches:
        raise FileNotFoundError(f"result.json not found under {BASE_DIR}")
    return matches[0]


def load_layout():
    layout_file = find_layout_file()
    data = json.loads(layout_file.read_text(encoding="utf-8"))
    data["_layout_file"] = str(layout_file)
    return data


def find_schedule_file():
    matches = sorted(BASE_DIR.glob("*/final_schedule.json"))
    if not matches:
        raise FileNotFoundError(f"final_schedule.json not found under {BASE_DIR}")
    return matches[0]


def load_schedule():
    schedule_file = find_schedule_file()
    data = json.loads(schedule_file.read_text(encoding="utf-8"))
    data["_schedule_file"] = str(schedule_file)
    return data

def build_drop_points():
    """Build AGV drop points from 布局/result.json.

    result.json coordinates are [row, col] in a 15x20 row-major matrix.
    Each positive station cell is scaled into a 3x3 station block.
    """
    data = load_layout()
    rows, cols = data["layout_shape"]
    vector = data["layout_vector"]
    station_cols = data["station_cols"]
    matrix = [vector[r * cols:(r + 1) * cols] for r in range(rows)]

    drop_points = []
    for label, col in station_cols.items():
        station_items = []
        for row in range(rows):
            station_no = matrix[row][col]
            if station_no > 0:
                x = LAYOUT_X0 + col * LAYOUT_CELL_SPACING
                y = LAYOUT_Y0 + row * LAYOUT_CELL_SPACING
                station_items.append((station_no, x, y))

        for station_no, x, y in sorted(station_items):
            drop_points.append(DropPoint(f"DP-{label}-{station_no:02d}", label, x, y))

    return drop_points


def build_agvs():
    return [
        AGVHome(str(i + 1), SHARED_HOME_X, SHARED_HOME_Y, 180)
        for i in range(MAX_CANDIDATE_AGVS)
    ]


def station_cells(x, y):
    return {
        (x + dx, y + dy)
        for dx in range(STATION_W)
        for dy in range(STATION_H)
    }


def station_unload_points(x, y):
    return [
        (x, y - 1),
        (x, y + STATION_H),
    ]


def validate_layout(drop_points):
    occupied = {}
    blocked = {SUPPLY_POS}

    for _, _, x, y in PICKUP_POINTS:
        if not (1 <= x <= GRID_W and 1 <= y <= GRID_H):
            raise ValueError(f"pickup point out of bounds: {(x, y)}")

    for dp in drop_points:
        for cell in station_cells(dp.x, dp.y):
            if not (1 <= cell[0] <= GRID_W and 1 <= cell[1] <= GRID_H):
                raise ValueError(f"station {dp.name} out of bounds: {cell}")

            if cell in occupied:
                raise ValueError(f"station overlap: {dp.name} with {occupied[cell]} at {cell}")

            occupied[cell] = dp.name
            blocked.add(cell)

        for p in station_unload_points(dp.x, dp.y):
            if not (1 <= p[0] <= GRID_W and 1 <= p[1] <= GRID_H):
                raise ValueError(f"station {dp.name} unload point out of bounds: {p}")
            if p in blocked:
                raise ValueError(f"station {dp.name} unload point blocked: {p}")

    for name, _, x, y in PICKUP_POINTS:
        if (x, y) in blocked:
            raise ValueError(f"pickup point {name} overlaps blocked cell: {(x, y)}")

    if SUPPLY_POS in occupied:
        raise ValueError("supply point overlaps a station")

    if (SHARED_HOME_X, SHARED_HOME_Y) in blocked:
        raise ValueError("AGV home overlaps blocked cell")


def write_positions(drop_points, agvs, filename=None):
    if filename is None:
        filename = BASE_DIR / "agv_position.csv"
    fields = ["type", "name", "label", "x", "y", "pitch"]

    with open(filename, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()

        writer.writerow({
            "type": "supply",
            "name": "SUPPLY-01",
            "label": "SUPPLY",
            "x": SUPPLY_POS[0],
            "y": SUPPLY_POS[1],
            "pitch": "",
        })

        for name, label, x, y in PICKUP_POINTS:
            writer.writerow({
                "type": "pickup_slot",
                "name": name,
                "label": label,
                "x": x,
                "y": y,
                "pitch": "",
            })

        for dp in drop_points:
            writer.writerow({
                "type": "drop_point",
                "name": dp.name,
                "label": dp.label,
                "x": dp.x,
                "y": dp.y,
                "pitch": "",
            })

        for agv in agvs:
            writer.writerow({
                "type": "agv",
                "name": agv.name,
                "label": f"AGV{agv.name}",
                "x": agv.x,
                "y": agv.y,
                "pitch": agv.pitch,
            })


def station_name_for_drop_point(dp):
    station_no = int(dp.name.rsplit("-", 1)[1])
    return f"{dp.label}_{station_no - 1}"


def demand_from_workers(workers):
    workers = int(workers or 0)
    if workers <= 5:
        return 2
    if workers <= 10:
        return 4
    if workers <= 15:
        return 6
    return 8


def material_from_schedule_item(item):
    operation = item.get("operation", "MAT")
    aircraft_type = item.get("type", "")
    return f"{operation}-{aircraft_type}" if aircraft_type else operation

def write_tasks(drop_points, filename=None, schedule_data=None):
    if filename is None:
        filename = BASE_DIR / "agv_task.csv"
    if schedule_data is None:
        schedule_data = load_schedule()

    fields = [
        "task_id",
        "destination_id",
        "destination_label",
        "material",
        "release_time",
        "window_start",
        "window_end",
        "priority",
        "demand",
        "delivery_takt",
        "material_takt",
        "takt",
        "takt_start",
        "takt_end",
        "aircraft_id",
        "operation",
        "operation_index",
        "station_name",
        "status",
        "workers",
    ]

    drop_by_station_name = {
        station_name_for_drop_point(dp): dp
        for dp in drop_points
    }

    tasks = []
    seen_operations = set()
    task_no = 1
    cumulative_time = 0
    missing_stations = set()
    takt_start_by_takt = {}
    takt_end_by_takt = {}
    for snapshot in schedule_data.get("takt_snapshots", []):
        takt = int(snapshot.get("takt", 0))
        takt_time_hours = float(snapshot.get("takt_time", 0))
        takt_time = int(round(takt_time_hours * TAKT_TO_AGV_TIME))
        takt_start_by_takt[takt] = cumulative_time
        takt_end_by_takt[takt] = cumulative_time + takt_time
        cumulative_time += takt_time

    for snapshot in schedule_data.get("takt_snapshots", []):
        takt = int(snapshot.get("takt", 0))
        takt_time = takt_end_by_takt[takt] - takt_start_by_takt[takt]
        takt_start = takt_start_by_takt[takt]
        takt_end = takt_end_by_takt[takt]

        for item in snapshot.get("positions", []):
            if item.get("status") != "processing":
                continue

            station_name = item.get("station_name", "").strip()
            dp = drop_by_station_name.get(station_name)
            if dp is None:
                missing_stations.add(station_name)
                continue

            operation_key = (
                item.get("aircraft_id", ""),
                int(item.get("operation_index", 0)),
                station_name,
            )
            if operation_key in seen_operations:
                continue
            seen_operations.add(operation_key)

            workers = int(item.get("workers", 0) or 0)
            delivery_takt = max(0, takt - 1)
            delivery_start = 0 if takt == 0 else takt_start_by_takt.get(delivery_takt, 0)
            delivery_end = max(delivery_start + 1, takt_start if takt > 0 else takt_end)
            tasks.append({
                "task_id": f"T{task_no:04d}",
                "destination_id": dp.name,
                "destination_label": dp.label,
                "material": material_from_schedule_item(item),
                "release_time": delivery_start,
                "window_start": delivery_start,
                "window_end": delivery_end,
                "priority": "Normal",
                "demand": demand_from_workers(workers),
                "delivery_takt": delivery_takt,
                "material_takt": takt,
                "takt": takt,
                "takt_start": takt_start,
                "takt_end": takt_end,
                "aircraft_id": item.get("aircraft_id", ""),
                "operation": item.get("operation", ""),
                "operation_index": item.get("operation_index", ""),
                "station_name": station_name,
                "status": item.get("status", ""),
                "workers": workers,
            })
            task_no += 1

    if missing_stations:
        missing = ", ".join(sorted(missing_stations))
        raise ValueError(f"final_schedule contains stations missing from layout: {missing}")

    tasks.sort(key=lambda r: (r["release_time"], r["window_start"], r["task_id"]))

    with open(filename, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(tasks)

    return tasks

def main():
    random.seed(RANDOM_SEED)

    layout_data = load_layout()
    schedule_data = load_schedule()
    drop_points = build_drop_points()
    agvs = build_agvs()

    validate_layout(drop_points)

    write_positions(drop_points, agvs)
    tasks = write_tasks(drop_points, schedule_data=schedule_data)

    print("数据生成完成")
    print(f"脚本路径: {Path(__file__).resolve()}")
    print(f"布局来源: {layout_data['_layout_file']}")
    print(f"工序计划来源: {schedule_data['_schedule_file']}")
    print(f"地图尺寸: {GRID_W} x {GRID_H}")
    print(f"时间换算: 1 takt_time小时 = {TAKT_TO_AGV_TIME} AGV时间步, 1 AGV时间步 = {AGV_SECONDS_PER_STEP}秒")
    print(f"工位尺寸: {STATION_W} x {STATION_H}")
    print(f"候选 AGV 数量: {MAX_CANDIDATE_AGVS}")
    print(f"工位数量: {len(drop_points)}")
    counts = {}
    for dp in drop_points:
        counts[dp.label] = counts.get(dp.label, 0) + 1
    print(f"各类工位数量: {counts}")
    print(f"任务数量: {len(tasks)}")
    print(f"节拍数量: {len(schedule_data.get('takt_snapshots', []))}")
    print(f"物料区: {SUPPLY_POS}")
    print(f"取料点: {[p[2:] for p in PICKUP_POINTS]}")
    print(f"AGV 等候区: {(SHARED_HOME_X, SHARED_HOME_Y)}")
    print("输出文件: agv_position.csv, agv_task.csv")

if __name__ == "__main__":
    main()
