﻿import csv
import heapq
import os
from collections import defaultdict
from pathlib import Path

# ============================================================
# 基础参数
# ============================================================

GRID_W = 106
GRID_H = 90
STATION_W = 3
STATION_H = 3

BASE_DIR = Path(__file__).resolve().parent
POSITION_FILE = BASE_DIR / "agv_position.csv"
TASK_FILE = BASE_DIR / "agv_task.csv"
TRAJECTORY_FILE = BASE_DIR / "agv_trajectory.csv"
TASK_RESULT_FILE = BASE_DIR / "agv_task_result.csv"
SUMMARY_FILE = BASE_DIR / "agv_summary.csv"

LOAD_DURATION = 2
UNLOAD_DURATION = 2
MAX_SEARCH_TIME = int(os.environ.get("MAX_SEARCH_TIME", "1200"))
MAX_ASTAR_EXPANSIONS = int(os.environ.get("MAX_ASTAR_EXPANSIONS", "12000"))

# 共享虚拟等待区
SHARED_HOME_POS = (101, 32)

# 固定启用 AGV 数量。
# 本版本不优化动态 AGV 数量，只在固定 AGV 集合内优化任务分配、排序与路径。
# 默认固定 5 台；也可以用环境变量覆盖：
#   MAX_ACTIVE_AGVS=5 python navigation.py
#   FIXED_AGV_IDS=1,3,5,7,9 python navigation.py
MAX_ACTIVE_AGVS = int(os.environ.get("MAX_ACTIVE_AGVS", "10"))
FIXED_AGV_IDS = os.environ.get("FIXED_AGV_IDS", "").strip()
ROLLING_TAKT_WINDOW = int(os.environ.get("ROLLING_TAKT_WINDOW", "1"))
ROLLING_MIN_TASKS = int(os.environ.get("ROLLING_MIN_TASKS", "80"))

DIRS = [
    (1, 0),
    (-1, 0),
    (0, 1),
    (0, -1),
    (0, 0),
]

PITCH_MAP = {
    (1, 0): 0,
    (-1, 0): 180,
    (0, 1): 90,
    (0, -1): 270,
    (0, 0): None,
}


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def neighbors(pos):
    x, y = pos

    for dx, dy in DIRS:
        nx = x + dx
        ny = y + dy

        if 1 <= nx <= GRID_W and 1 <= ny <= GRID_H:
            yield nx, ny


class ReservationTable:
    """
    时空预约表。

    vertex[t][pos] = agv_id
        表示 t 时刻 pos 被某台 AGV 占用。

    edge[t][(from_pos, to_pos)] = agv_id
        表示 t-1 到 t 该 AGV 从 from_pos 到 to_pos。

    共享等待区 SHARED_HOME_POS 是虚拟区域，允许 AGV 重叠。
    """

    def __init__(self):
        self.vertex = defaultdict(dict)
        self.edge = defaultdict(dict)

    def clone(self):
        other = ReservationTable()
        other.vertex = defaultdict(dict, {t: dict(v) for t, v in self.vertex.items()})
        other.edge = defaultdict(dict, {t: dict(v) for t, v in self.edge.items()})
        return other

    def is_free(self, agv_id, prev_pos, pos, t):
        """
        判断 AGV 在 t 时刻从 prev_pos 到 pos 是否可用。

        共享等待区允许多车重叠。
        普通道路仍然禁止顶点冲突和对穿冲突。
        """
        if pos != SHARED_HOME_POS:
            owner = self.vertex.get(t, {}).get(pos)
            if owner is not None and owner != agv_id:
                return False

        if pos != SHARED_HOME_POS and prev_pos != SHARED_HOME_POS:
            reverse_owner = self.edge.get(t, {}).get((pos, prev_pos))
            if reverse_owner is not None and reverse_owner != agv_id:
                return False

        return True

    def can_hold(self, agv_id, pos, start_t, duration):
        for t in range(start_t, start_t + duration + 1):
            if not self.is_free(agv_id, pos, pos, t):
                return False

        return True

    def reserve_path(self, agv_id, path):
        for idx, (pos, t) in enumerate(path):
            prev_pos = path[idx - 1][0] if idx > 0 else pos

            if not self.is_free(agv_id, prev_pos, pos, t):
                raise RuntimeError(f"预约冲突: AGV{agv_id}, t={t}, pos={pos}")

        for idx, (pos, t) in enumerate(path):
            self.vertex[t][pos] = agv_id

            if idx > 0:
                prev_pos = path[idx - 1][0]
                self.edge[t][(prev_pos, pos)] = agv_id


class Planner:
    def __init__(self):
        self.supply = None
        self.pickups = {}
        self.drop_points = {}
        self.homes = {}
        self.tasks = []

        self.res = ReservationTable()

        self.agv_states = {}
        self.active_agvs = []
        self.agv_tracks = defaultdict(list)

        self.task_results = []
        self.total_distance = 0
        self.total_delay = 0

        self.load_inputs()

    # ============================================================
    # 数据读取
    # ============================================================

    def load_inputs(self):
        with open(POSITION_FILE, "r", encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                item = {
                    "name": row["name"].strip(),
                    "label": row.get("label", "").strip(),
                    "pos": (int(row["x"]), int(row["y"])),
                    "pitch": int(row["pitch"]) if row.get("pitch") not in ("", None) else 180,
                }

                row_type = row["type"].strip()

                if row_type == "supply":
                    self.supply = item
                elif row_type == "pickup_slot":
                    self.pickups[item["name"]] = item
                elif row_type == "drop_point":
                    self.drop_points[item["name"]] = item
                elif row_type == "agv":
                    self.homes[item["name"]] = item

        with open(TASK_FILE, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            if "demand" not in (reader.fieldnames or []):
                raise ValueError(
                    "agv_task.csv 缺少 demand 字段，协同任务分配无法参与优化。"
                    "请先运行: python generate_data.py"
                )

            for row in reader:
                demand = int(row["demand"])
                if demand not in (2, 4, 6, 8):
                    raise ValueError(f"任务 {row['task_id']} 的 demand={demand} 非法，应为 2/4/6/8")

                self.tasks.append({
                    "task_id": row["task_id"].strip(),
                    "destination_id": row["destination_id"].strip(),
                    "destination_label": row["destination_label"].strip(),
                    "material": row["material"].strip(),
                    "release_time": int(row["release_time"]),
                    "window_start": int(row["window_start"]),
                    "window_end": int(row["window_end"]),
                    "priority": row.get("priority", "Normal"),
                    "demand": demand,
                    "delivery_takt": int(row.get("delivery_takt", row.get("takt", 0)) or 0),
                    "material_takt": int(row.get("material_takt", row.get("takt", 0)) or 0),
                    "takt": int(row.get("takt", 0) or 0),
                    "takt_start": int(row.get("takt_start", row.get("window_start", 0)) or 0),
                    "takt_end": int(row.get("takt_end", row.get("window_end", 0)) or 0),
                    "aircraft_id": row.get("aircraft_id", "").strip(),
                    "operation": row.get("operation", "").strip(),
                    "operation_index": row.get("operation_index", ""),
                    "station_name": row.get("station_name", "").strip(),
                    "workers": row.get("workers", ""),
                })

        self.tasks.sort(key=lambda r: (r["release_time"], r["window_start"], r["task_id"]))

        # 固定启用 AGV 集合。
        # 注意：这里不做 AGV 数量优化。候选 AGV 可以很多，
        # 但每次优化只使用 fixed_agv_ids 这组固定 AGV。
        if FIXED_AGV_IDS:
            fixed_agv_ids = [x.strip() for x in FIXED_AGV_IDS.split(",") if x.strip()]
            missing = [x for x in fixed_agv_ids if x not in self.homes]
            if missing:
                raise ValueError(f"FIXED_AGV_IDS 中存在 agv_position.csv 没有的 AGV: {missing}")
        else:
            fixed_agv_ids = sorted(self.homes, key=lambda x: int(x))[:MAX_ACTIVE_AGVS]

        if not fixed_agv_ids:
            raise ValueError("没有可启用的 AGV，请检查 agv_position.csv 或 FIXED_AGV_IDS")

        self.active_agvs = list(fixed_agv_ids)

        for agv_id in self.active_agvs:
            self.agv_states[agv_id] = {
                "id": agv_id,
                "pos": SHARED_HOME_POS,
                "time": 0,
                "pitch": self.homes[agv_id]["pitch"],
                "home": SHARED_HOME_POS,
            }

            self.agv_tracks[agv_id].append(
                self.make_row(
                    0,
                    agv_id,
                    SHARED_HOME_POS,
                    180,
                    False,
                    "",
                    "",
                    "",
                    "",
                    "idle",
                )
            )

        if self.supply is None:
            raise ValueError("agv_position.csv 缺少物料区 supply")

        if not self.pickups:
            raise ValueError("agv_position.csv 缺少取料点 pickup_slot")

        if not self.drop_points:
            raise ValueError("agv_position.csv 缺少工位 drop_point")

        print(f"地图尺寸: {GRID_W} x {GRID_H}")
        print(f"工位尺寸: {STATION_W} x {STATION_H}")
        print(f"固定启用 AGV 数量: {len(self.active_agvs)}")
        print(f"固定启用 AGV ID: {','.join(self.active_agvs)}")
        print(f"取料点数量: {len(self.pickups)}")
        print(f"工位数量: {len(self.drop_points)}")
        print(f"任务数量: {len(self.tasks)}")
        print(f"协同任务数量: {sum(1 for task in self.tasks if task['demand'] > 2)}")

    # ============================================================
    # 地图与工位函数
    # ============================================================

    def station_cells(self, station_pos):
        """
        station_pos 是工位 3x3 区域左下角。
        返回该工位本体占用的全部网格。
        """
        sx, sy = station_pos

        return {
            (sx + dx, sy + dy)
            for dx in range(STATION_W)
            for dy in range(STATION_H)
        }

    def station_delivery_points(self, station_pos):
        """
        每个工位只有两个合法卸货点：
        1. 工位左下角下方一格
        2. 工位左上角上方一格

        例如工位左下角为 (3, 4)，左上角为 (3, 6)，
        则卸货点为 (3, 3) 和 (3, 7)。
        """
        sx, sy = station_pos

        return [
            (sx, sy - 1),
            (sx, sy + STATION_H),
        ]

    def static_blocked(self, extra_blocked=None):
        """
        静态障碍：
        1. 物料区本体；
        2. 每个工位 3x3 本体；
        3. extra_blocked 中指定的临时障碍。

        注意：
        - 取料点不是静态障碍，AGV 需要进入取料点取料。
        - 卸货点不是静态障碍，AGV 需要进入卸货点卸货。
        """
        blocked = {self.supply["pos"]}

        for dp in self.drop_points.values():
            blocked.update(self.station_cells(dp["pos"]))

        if extra_blocked:
            blocked.update(extra_blocked)

        return blocked

    def traversable(self, pos, extra_blocked=None):
        return (
            1 <= pos[0] <= GRID_W
            and 1 <= pos[1] <= GRID_H
            and pos not in self.static_blocked(extra_blocked)
        )

    def delivery_goals(self, destination_id, extra_blocked=None):
        """
        AGV 只能到达该工位左下方或左上方卸货点。
        不再允许到工位周边任意格卸货。
        """
        station_pos = self.drop_points[destination_id]["pos"]
        candidates = self.station_delivery_points(station_pos)

        goals = [
            p
            for p in candidates
            if self.traversable(p, extra_blocked)
        ]

        if not goals:
            raise RuntimeError(f"工位 {destination_id} 没有可用卸货点: {candidates}")

        return goals

    # ============================================================
    # 路径规划
    # ============================================================

    def heuristic(self, pos, goals):
        return min(manhattan(pos, g) for g in goals)

    def astar_time(
        self,
        res,
        agv_id,
        start_pos,
        start_time,
        goals,
        earliest_goal_time=0,
        extra_blocked=None,
        goal_hold=0,
    ):
        blocked = self.static_blocked(extra_blocked)
        goals = set(goals)

        start_state = (start_pos, start_time)

        pq = [
            (
                self.heuristic(start_pos, goals),
                0,
                start_pos,
                start_time,
            )
        ]

        parent = {start_state: None}
        best = {start_state: 0}
        expansions = 0

        while pq:
            _, cost, pos, t = heapq.heappop(pq)
            state = (pos, t)
            expansions += 1
            if expansions > MAX_ASTAR_EXPANSIONS:
                return None

            if pos in goals:
                goal_t = max(t, earliest_goal_time)
                hold_duration = goal_t - t + goal_hold
                if not res.can_hold(agv_id, pos, t, hold_duration):
                    pass
                else:
                    path = []

                    while state is not None:
                        path.append(state)
                        state = parent[state]

                    path.reverse()

                    if goal_t > t:
                        path.extend((pos, wait_t) for wait_t in range(t + 1, goal_t + 1))

                    return path

            if t - start_time > MAX_SEARCH_TIME:
                continue

            for nxt in neighbors(pos):
                nt = t + 1

                if nxt in blocked and nxt not in goals:
                    continue

                if not res.is_free(agv_id, pos, nxt, nt):
                    continue

                nstate = (nxt, nt)
                ncost = cost + 1

                if nstate not in best or ncost < best[nstate]:
                    best[nstate] = ncost
                    parent[nstate] = state

                    priority = (
                        ncost
                        + self.heuristic(nxt, goals)
                        + max(0, earliest_goal_time - nt)
                    )

                    heapq.heappush(pq, (priority, ncost, nxt, nt))

        return None

    def wait_path(self, pos, start_t, duration):
        return [
            (pos, t)
            for t in range(start_t, start_t + duration + 1)
        ]

    def path_distance(self, path):
        if not path or len(path) <= 1:
            return 0

        return sum(
            1
            for i in range(1, len(path))
            if path[i][0] != path[i - 1][0]
        )

    def choose_best_pickup_path(self, res, agv_id, start_pos, start_time, release_time):
        best = None

        for pickup in self.pickups.values():
            path = self.astar_time(
                res,
                agv_id,
                start_pos,
                start_time,
                [pickup["pos"]],
                earliest_goal_time=release_time,
                goal_hold=LOAD_DURATION,
            )

            if path is None:
                continue

            score = (
                path[-1][1],
                self.path_distance(path),
                pickup["name"],
            )

            if best is None or score < best[0]:
                best = (score, pickup, path)

        if best is None:
            return None

        return best[1], best[2]

    def try_reserve_path(self, res, agv_id, path):
        try:
            res.reserve_path(agv_id, path)
            return True
        except RuntimeError:
            return False

    def build_candidate_plan(self, agv_id, task):
        st = self.agv_states[agv_id]

        temp_res = self.res.clone()
        cur_pos = st["pos"]
        cur_time = st["time"]

        segments = []

        # 如果 AGV 在共享等待区，不预约等待，只从合适时间出发，避免过早堵在取料区。
        if cur_pos == SHARED_HOME_POS:
            dist_to_pick = min(
                manhattan(cur_pos, pickup["pos"])
                for pickup in self.pickups.values()
            )

            cur_time = max(
                cur_time,
                task["release_time"] - dist_to_pick - 5,
                0,
            )

        # 1. 去取料点
        pickup_plan = self.choose_best_pickup_path(
            temp_res,
            agv_id,
            cur_pos,
            cur_time,
            task["release_time"],
        )

        if pickup_plan is None:
            return None

        pickup, path_to_pick = pickup_plan

        if not self.try_reserve_path(temp_res, agv_id, path_to_pick):
            return None

        segments.append((
            "to_pickup",
            False,
            "",
            "",
            "",
            "",
            path_to_pick,
        ))

        # 2. 取料
        load_path = self.wait_path(
            pickup["pos"],
            path_to_pick[-1][1],
            LOAD_DURATION,
        )

        if not self.try_reserve_path(temp_res, agv_id, load_path):
            return None

        segments.append((
            "loading",
            False,
            "",
            "",
            "",
            "",
            load_path,
        ))

        # 3. 配送
        # 配送阶段禁止穿过取料点。
        extra_blocked = {
            pickup_item["pos"]
            for pickup_item in self.pickups.values()
        }

        goals = self.delivery_goals(task["destination_id"], extra_blocked)

        path_to_drop = self.astar_time(
            temp_res,
            agv_id,
            pickup["pos"],
            load_path[-1][1],
            goals,
            extra_blocked=extra_blocked,
            goal_hold=UNLOAD_DURATION,
        )

        if path_to_drop is None:
            return None

        if not self.try_reserve_path(temp_res, agv_id, path_to_drop):
            return None

        segments.append((
            "delivering",
            True,
            task["material"],
            task["destination_label"],
            task["destination_id"],
            task["task_id"],
            path_to_drop,
        ))

        unload_pos = path_to_drop[-1][0]
        delivery_time = path_to_drop[-1][1]

        # 4. 卸货
        unload_path = self.wait_path(
            unload_pos,
            delivery_time,
            UNLOAD_DURATION,
        )

        if not self.try_reserve_path(temp_res, agv_id, unload_path):
            return None

        segments.append((
            "unloading",
            True,
            task["material"],
            task["destination_label"],
            task["destination_id"],
            task["task_id"],
            unload_path,
        ))

        # 5. 回共享等待区
        path_home = self.astar_time(
            temp_res,
            agv_id,
            unload_path[-1][0],
            unload_path[-1][1],
            [SHARED_HOME_POS],
            extra_blocked=extra_blocked,
        )

        if path_home is None:
            return None

        if not self.try_reserve_path(temp_res, agv_id, path_home):
            return None

        segments.append((
            "return_home",
            False,
            "",
            "",
            "",
            "",
            path_home,
        ))

        distance = sum(
            self.path_distance(seg[-1])
            for seg in segments
        )

        delay = max(0, delivery_time - task["window_start"])
        finish_time = path_home[-1][1]

        return {
            "agv_id": agv_id,
            "segments": segments,
            "res": temp_res,
            "delivery_time": delivery_time,
            "finish_time": finish_time,
            "finish_pos": SHARED_HOME_POS,
            "distance": distance,
            "delay": delay,
            "pickup": pickup,
            "unload_pos": unload_pos,
        }

    def choose_agv_for_task(self, task):
        best = None

        for agv_id in self.active_agvs:
            plan = self.build_candidate_plan(agv_id, task)

            if plan is None:
                continue

            score = (
                plan["delay"] * 1000 + plan["finish_time"] + plan["distance"],
                plan["delay"],
                plan["finish_time"],
                int(agv_id),
            )

            if best is None or score < best[0]:
                best = (score, plan)

        if best is None:
            raise RuntimeError(f"任务 {task['task_id']} 找不到可行 AGV")

        return best[1]

    # ============================================================
    # 轨迹输出
    # ============================================================

    def make_row(
        self,
        t,
        agv_id,
        pos,
        pitch,
        loaded,
        material,
        dest_label,
        dest_id,
        task_id,
        status,
    ):
        return {
            "timestamp": t,
            "name": agv_id,
            "X": pos[0],
            "Y": pos[1],
            "pitch": pitch,
            "loaded": "true" if loaded else "false",
            "material": material,
            "destination_label": dest_label,
            "destination_id": dest_id,
            "task_id": task_id,
            "status": status,
            "pos": pos,
        }

    def path_pitch(self, prev_pos, curr_pos, old_pitch):
        dx = curr_pos[0] - prev_pos[0]
        dy = curr_pos[1] - prev_pos[1]

        return PITCH_MAP.get((dx, dy), old_pitch) or old_pitch

    def append_path_rows(
        self,
        agv_id,
        path,
        loaded,
        material,
        dest_label,
        dest_id,
        task_id,
        status,
    ):
        rows = self.agv_tracks[agv_id]

        if not rows:
            rows.append(
                self.make_row(
                    path[0][1],
                    agv_id,
                    path[0][0],
                    180,
                    False,
                    "",
                    "",
                    "",
                    "",
                    "idle",
                )
            )

        while rows[-1]["timestamp"] < path[0][1] - 1:
            last = rows[-1]

            rows.append(
                self.make_row(
                    last["timestamp"] + 1,
                    agv_id,
                    last["pos"],
                    last["pitch"],
                    False,
                    "",
                    "",
                    "",
                    "",
                    "idle",
                )
            )

        prev_pos = rows[-1]["pos"]
        pitch = rows[-1]["pitch"]

        for pos, t in path[1:]:
            pitch = self.path_pitch(prev_pos, pos, pitch)

            rows.append(
                self.make_row(
                    t,
                    agv_id,
                    pos,
                    pitch,
                    loaded,
                    material,
                    dest_label,
                    dest_id,
                    task_id,
                    status,
                )
            )

            prev_pos = pos

    def commit_plan(self, task, plan):
        agv_id = plan["agv_id"]

        for status, loaded, material, dest_label, dest_id, task_id, path in plan["segments"]:
            self.append_path_rows(
                agv_id,
                path,
                loaded,
                material,
                dest_label,
                dest_id,
                task_id,
                status,
            )

        self.res = plan["res"]

        self.agv_states[agv_id]["pos"] = plan["finish_pos"]
        self.agv_states[agv_id]["time"] = plan["finish_time"]

        self.total_distance += plan["distance"]
        self.total_delay += plan["delay"]

        self.task_results.append({
            "task_id": task["task_id"],
            "destination_id": task["destination_id"],
            "destination_label": task["destination_label"],
            "material": task["material"],
            "agv_id": agv_id,
            "window_start": task["window_start"],
            "window_end": task["window_end"],
            "delivery_time": plan["delivery_time"],
            "delay": plan["delay"],
            "distance": plan["distance"],
            "pickup": plan["pickup"]["label"],
            "unload_x": plan["unload_pos"][0],
            "unload_y": plan["unload_pos"][1],
        })

    def fill_idle_until_end(self):
        max_t = 0

        for agv_id in self.active_agvs:
            if self.agv_tracks[agv_id]:
                max_t = max(max_t, self.agv_tracks[agv_id][-1]["timestamp"])

        for agv_id in self.active_agvs:
            rows = self.agv_tracks[agv_id]

            while rows and rows[-1]["timestamp"] < max_t:
                last = rows[-1]

                rows.append(
                    self.make_row(
                        last["timestamp"] + 1,
                        agv_id,
                        last["pos"],
                        last["pitch"],
                        False,
                        "",
                        "",
                        "",
                        "",
                        "idle",
                    )
                )

    def build_rows(self):
        fields = [
            "timestamp",
            "name",
            "X",
            "Y",
            "pitch",
            "loaded",
            "material",
            "destination_label",
            "destination_id",
            "task_id",
            "status",
        ]

        rows = []

        for agv_id in self.active_agvs:
            last_by_time = {
                r["timestamp"]: r
                for r in self.agv_tracks[agv_id]
            }

            rows.extend(
                {k: r[k] for k in fields}
                for r in last_by_time.values()
            )

        rows.sort(key=lambda r: (int(r["timestamp"]), int(r["name"])))

        return rows

    def write_outputs(self):
        self.fill_idle_until_end()

        rows = self.build_rows()

        trajectory_fields = [
            "timestamp",
            "name",
            "X",
            "Y",
            "pitch",
            "loaded",
            "material",
            "destination_label",
            "destination_id",
            "task_id",
            "status",
        ]

        with open(TRAJECTORY_FILE, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=trajectory_fields)
            writer.writeheader()
            writer.writerows(rows)

        result_fields = [
            "task_id",
            "destination_id",
            "destination_label",
            "material",
            "demand",
            "required_agv_count",
            "agv_id",
            "assigned_agvs",
            "window_start",
            "window_end",
            "arrival_time",
            "delivery_time",
            "delay",
            "distance",
            "pickup",
            "pickups",
            "unload_x",
            "unload_y",
            "subtask_count",
            "sync_gap",
        ]

        with open(TASK_RESULT_FILE, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=result_fields)
            writer.writeheader()
            writer.writerows(self.task_results)

        max_delay = max((r["delay"] for r in self.task_results), default=0)

        avg_delay = (
            sum(r["delay"] for r in self.task_results) / len(self.task_results)
            if self.task_results
            else 0
        )

        makespan = max((int(r["timestamp"]) for r in rows), default=0)

        with open(SUMMARY_FILE, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(["metric", "value"])
            writer.writerow(["candidate_agv_count", len(self.homes)])
            writer.writerow(["fixed_active_agv_count", len(self.active_agvs)])
            writer.writerow(["fixed_active_agv_ids", ",".join(self.active_agvs)])
            writer.writerow(["pickup_count", len(self.pickups)])
            writer.writerow(["station_size", f"{STATION_W}x{STATION_H}"])
            writer.writerow(["total_delay", self.total_delay])
            writer.writerow(["max_delay", max_delay])
            writer.writerow(["avg_delay", round(avg_delay, 2)])
            writer.writerow(["total_distance", self.total_distance])
            writer.writerow(["makespan", makespan])
            if hasattr(self, "best_score"):
                writer.writerow(["best_score", round(self.best_score, 4)])
            if hasattr(self, "total_tardiness"):
                writer.writerow(["total_tardiness", self.total_tardiness])
            if hasattr(self, "max_tardiness"):
                writer.writerow(["max_tardiness", self.max_tardiness])
            if hasattr(self, "total_wait"):
                writer.writerow(["total_wait", self.total_wait])
            if hasattr(self, "workload_imbalance"):
                writer.writerow(["workload_imbalance", self.workload_imbalance])
            if hasattr(self, "total_sync_gap"):
                writer.writerow(["total_sync_gap", self.total_sync_gap])
            if hasattr(self, "duplicate_agv_penalty"):
                writer.writerow(["duplicate_agv_penalty", self.duplicate_agv_penalty])
            if hasattr(self, "collaborative_task_count"):
                writer.writerow(["collaborative_task_count", self.collaborative_task_count])
            if hasattr(self, "rolling_window_count"):
                writer.writerow(["rolling_window_count", self.rolling_window_count])
            if hasattr(self, "rolling_takt_window"):
                writer.writerow(["rolling_takt_window", self.rolling_takt_window])

    # ============================================================
    # 主流程：GA-A*-CP 全局优化
    # ============================================================

    def _make_window_planner(self, tasks, initial_agv_states=None):
        clone = object.__new__(Planner)
        clone.__dict__ = self.__dict__.copy()
        clone.tasks = list(tasks)
        clone.res = self.res.__class__()
        clone.agv_tracks = {agv_id: [] for agv_id in self.active_agvs}
        clone.task_results = []
        clone.total_distance = 0
        clone.total_delay = 0
        clone.initial_agv_states = initial_agv_states or {}
        return clone

    def _merge_rolling_tracks(self, evals, windows):
        merged = {agv_id: [] for agv_id in self.active_agvs}
        seen = {agv_id: set() for agv_id in self.active_agvs}

        for idx, ev in enumerate(evals):
            lower = windows[idx]["min_release"] if idx > 0 else 0
            for agv_id in self.active_agvs:
                for row in ev.agv_tracks.get(agv_id, []):
                    ts = int(row["timestamp"])
                    if ts < lower:
                        continue
                    key = (ts, row.get("name", agv_id), row.get("status", ""), row.get("task_id", ""))
                    if key in seen[agv_id]:
                        continue
                    seen[agv_id].add(key)
                    merged[agv_id].append(row)

        for agv_id in self.active_agvs:
            merged[agv_id].sort(key=lambda r: int(r["timestamp"]))
        return merged

    def run_rolling(self):
        from ga_optimizer import GAAStarCPOptimizer

        rolling_key = "delivery_takt"
        takt_values = sorted({int(t.get(rolling_key, t.get("takt", 0))) for t in self.tasks})
        if not takt_values:
            raise ValueError("ROLLING_TAKT_WINDOW requires tasks with takt field")

        window_size = max(1, ROLLING_TAKT_WINDOW)
        windows = []
        for start in range(min(takt_values), max(takt_values) + 1, window_size):
            end = start + window_size - 1
            tasks = [t for t in self.tasks if start <= int(t.get(rolling_key, t.get("takt", 0))) <= end]
            if not tasks:
                continue
            windows.append({
                "start_takt": start,
                "end_takt": end,
                "tasks": tasks,
                "min_release": min(int(t["release_time"]) for t in tasks),
            })

        current_states = {
            agv_id: {
                "id": agv_id,
                "pos": self.agv_states[agv_id]["home"],
                "time": 0,
                "pitch": self.agv_states[agv_id]["pitch"],
                "home": self.agv_states[agv_id]["home"],
            }
            for agv_id in self.active_agvs
        }

        all_evals = []
        all_task_results = []
        total_score = 0
        total_distance = 0
        total_tardiness = 0
        max_tardiness = 0
        total_wait = 0
        total_sync_gap = 0
        duplicate_agv_penalty = 0
        collaborative_task_count = 0

        for idx, window in enumerate(windows, start=1):
            window_planner = self._make_window_planner(window["tasks"], current_states)
            pop = int(os.environ.get("ROLLING_GA_POPULATION", os.environ.get("GA_POPULATION", "8")))
            gens = int(os.environ.get("ROLLING_GA_GENERATIONS", os.environ.get("GA_GENERATIONS", "3")))
            optimizer = GAAStarCPOptimizer(
                planner=window_planner,
                population_size=pop,
                generations=gens,
                crossover_rate=0.75,
                mutation_rate=0.45,
                elite_size=max(1, min(2, pop)),
                seed=42 + idx,
            )
            print(
                f"ROLLING window {idx}/{len(windows)} | "
                f"delivery_takt={window['start_takt']}..{window['end_takt']} | "
                f"tasks={len(window['tasks'])} | pop={pop} | gen={gens}",
                flush=True,
            )
            _, ev = optimizer.solve()
            all_evals.append(ev)
            for agv_id in self.active_agvs:
                rows = ev.agv_tracks.get(agv_id, [])
                if rows:
                    last = rows[-1]
                    # A rolling takt is closed only after assigned AGVs return to
                    # the shared waiting area. The next takt therefore starts
                    # from home, not from the last unload point.
                    current_states[agv_id] = {
                        "id": agv_id,
                        "pos": self.agv_states[agv_id]["home"],
                        "time": int(last["timestamp"]),
                        "pitch": 180,
                        "home": self.agv_states[agv_id]["home"],
                    }
                else:
                    current_states[agv_id] = {
                        "id": agv_id,
                        "pos": self.agv_states[agv_id]["home"],
                        "time": int(current_states[agv_id].get("time", 0)),
                        "pitch": 180,
                        "home": self.agv_states[agv_id]["home"],
                    }
            all_task_results.extend(ev.task_results)
            total_score += ev.score
            total_distance += ev.total_distance
            total_tardiness += ev.total_tardiness
            max_tardiness = max(max_tardiness, ev.max_tardiness)
            total_wait += ev.total_wait
            total_sync_gap += ev.total_sync_gap
            duplicate_agv_penalty += ev.duplicate_agv_penalty
            collaborative_task_count += ev.collaborative_task_count

        self.agv_tracks = self._merge_rolling_tracks(all_evals, windows)
        self.task_results = sorted(all_task_results, key=lambda r: (int(r["window_start"]), r["task_id"]))
        self.total_distance = total_distance
        self.total_delay = total_tardiness
        self.best_score = total_score
        self.total_tardiness = total_tardiness
        self.max_tardiness = max_tardiness
        self.total_wait = total_wait
        self.workload_imbalance = 0
        self.total_sync_gap = total_sync_gap
        self.duplicate_agv_penalty = duplicate_agv_penalty
        self.collaborative_task_count = collaborative_task_count
        self.rolling_window_count = len(windows)
        self.rolling_takt_window = window_size

        self.write_outputs()

        print("=" * 60)
        print("ROLLING GA-A*-CP 优化完成")
        print(f"滚动窗口数量: {len(windows)}")
        print(f"每窗口节拍数: {window_size}")
        print("滚动逻辑: 第 k 拍配送第 k+1 拍加工任务所需物料")
        print(f"任务数量: {len(self.tasks)}")
        print(f"累计迟到 total_tardiness: {total_tardiness}")
        print(f"最大迟到 max_tardiness: {max_tardiness}")
        print(f"总行驶距离 total_distance: {total_distance}")
        print(f"总等待时间 total_wait: {total_wait}")
        print("输出文件: agv_trajectory.csv, agv_task_result.csv, agv_summary.csv")

    def run(self):
        """
        用 GA-A*-CP 替换原来的逐任务贪心:
        1) GA 在上层搜索所有任务的分配与排序;
        2) A*-CP 在下层对每个完整染色体做时空路径规划与碰撞预约;
        3) 最终只把最优染色体的 detailed evaluation 写入原有 CSV 输出。
        """
        if ROLLING_TAKT_WINDOW > 0 and len(self.tasks) >= ROLLING_MIN_TASKS and any("takt" in t for t in self.tasks):
            return self.run_rolling()

        from ga_optimizer import GAAStarCPOptimizer

        optimizer = GAAStarCPOptimizer(
            planner=self,
            population_size=20,
            generations=10,
            crossover_rate=0.75,
            mutation_rate=0.45,
            elite_size=3,
            seed=42,
        )

        best_chromosome, best_eval = optimizer.solve()

        self.agv_tracks = best_eval.agv_tracks
        self.task_results = best_eval.task_results
        self.total_distance = best_eval.total_distance
        self.total_delay = best_eval.total_tardiness

        # 额外统计字段，write_outputs 会保持原有 CSV 兼容；
        # GA 相关输出由 optimizer 写入 ga_history.csv / best_chromosome.csv。
        self.best_score = best_eval.score
        self.total_tardiness = best_eval.total_tardiness
        self.max_tardiness = best_eval.max_tardiness
        self.total_wait = best_eval.total_wait
        self.workload_imbalance = best_eval.workload_imbalance
        self.total_sync_gap = best_eval.total_sync_gap
        self.duplicate_agv_penalty = best_eval.duplicate_agv_penalty
        self.collaborative_task_count = best_eval.collaborative_task_count

        self.write_outputs()

        print("=" * 60)
        print("GA-A*-CP 全局优化完成")
        print(f"固定启用 AGV 数量: {len(self.active_agvs)}")
        print(f"固定启用 AGV ID: {','.join(self.active_agvs)}")
        print(f"最优 score: {best_eval.score:.2f}")
        print(f"累计时间窗迟到 total_tardiness: {best_eval.total_tardiness}")
        print(f"最大时间窗迟到 max_tardiness: {best_eval.max_tardiness}")
        print(f"总行驶距离 total_distance: {best_eval.total_distance}")
        print(f"总等待时间 total_wait: {best_eval.total_wait}")
        print(f"协同同步差 total_sync_gap: {best_eval.total_sync_gap}")
        print(f"同任务重复AGV惩罚 duplicate_agv_penalty: {best_eval.duplicate_agv_penalty}")
        print(f"协同任务数量 collaborative_task_count: {best_eval.collaborative_task_count}")
        print(f"完工时间 makespan: {best_eval.makespan}")
        print("输出文件: agv_trajectory.csv, agv_task_result.csv, agv_summary.csv")
        print("额外输出: ga_history.csv, best_chromosome.csv")


def main():
    Planner().run()


if __name__ == "__main__":
    main()
